from setuptools import setup
__project__='ISS_now'
__version__='0.0.3'
__description__='''a python moudle to display the coordinates of the international space station'''
__packages__=['ISS']
__author__ = "lzx-047"
setup(
    name = __project__,
    version = __version__,
    description = __description__,
    packages = __packages__,
    author = __author__,
)